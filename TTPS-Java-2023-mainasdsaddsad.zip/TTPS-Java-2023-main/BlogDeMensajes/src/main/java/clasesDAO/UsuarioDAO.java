package clasesDAO;

import clasesDeObjetosDelSistema.Usuario;

public interface UsuarioDAO {
	public Usuario encontrar(String email);
}

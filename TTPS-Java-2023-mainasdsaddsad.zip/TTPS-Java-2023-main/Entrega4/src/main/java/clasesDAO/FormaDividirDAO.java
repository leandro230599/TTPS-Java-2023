package clasesDAO;

import clasesModelo.FormaDividir;

public interface FormaDividirDAO extends GenericDAO<FormaDividir>{

}

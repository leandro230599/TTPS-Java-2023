package clasesDAO;

import clasesModelo.Pago;

public interface PagoDAO extends GenericDAO<Pago>{

}

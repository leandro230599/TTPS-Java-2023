# TTPS-Java-2023

Revisar ejercicio de clasificados y practica23 para que quede mas prolijo y entendible
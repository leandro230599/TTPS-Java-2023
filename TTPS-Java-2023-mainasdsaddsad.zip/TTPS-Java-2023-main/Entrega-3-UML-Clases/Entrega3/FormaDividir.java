package objects;

public class FormaDividir {
	public double dividirGasto(String tipo) {
		return 0;
	}
}

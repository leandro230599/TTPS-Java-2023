package ttps.spring.clasesDAO;

import ttps.spring.model.Gasto;

public interface GastoDAO extends GenericDAO<Gasto>{

}

package clasesDAO;

import clasesModelo.Gasto;

public interface GastoDAO extends GenericDAO<Gasto>{

}

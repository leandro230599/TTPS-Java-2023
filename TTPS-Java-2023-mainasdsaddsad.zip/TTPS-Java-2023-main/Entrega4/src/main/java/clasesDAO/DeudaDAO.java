package clasesDAO;
import clasesModelo.Deuda;


public interface DeudaDAO extends GenericDAO<Deuda> {

}

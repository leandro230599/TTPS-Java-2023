package clasesDeObjetosDelSistema;

public class Usuario {
	private String email;

	public Usuario() {
		super();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}

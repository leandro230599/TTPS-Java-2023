package ttps.spring.clasesDAO;
import ttps.spring.model.Deuda;


public interface DeudaDAO extends GenericDAO<Deuda> {

}

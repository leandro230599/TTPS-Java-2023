package ttps.spring.clasesDAO;

import ttps.spring.model.Pago;

public interface PagoDAO extends GenericDAO<Pago>{

}

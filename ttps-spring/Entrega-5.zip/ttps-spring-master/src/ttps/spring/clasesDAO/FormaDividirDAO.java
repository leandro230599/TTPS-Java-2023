package ttps.spring.clasesDAO;

import ttps.spring.model.FormaDividir;

public interface FormaDividirDAO extends GenericDAO<FormaDividir>{
}
